﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.models
{
    public class RetornoApi
    {
        public string menssagem { get; set; }
        public List<int> jogo { get; set; }
    }
}
