﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.models
{
    public class Exemplo2
    {
       public int numeroJogo { get; set; }
    }
}
